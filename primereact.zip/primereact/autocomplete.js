'use strict';

module.exports = require('./components/autocomplete/AutoComplete');