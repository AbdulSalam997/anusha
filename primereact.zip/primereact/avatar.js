'use strict';

module.exports = require('./components/avatar/Avatar');