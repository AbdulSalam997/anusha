'use strict';

module.exports = require('./components/button/Button.js');