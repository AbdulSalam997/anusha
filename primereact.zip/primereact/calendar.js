'use strict';

module.exports = require('./components/calendar/Calendar.js');