'use strict';

module.exports = require('./components/chart/Chart');