'use strict';

module.exports = require('./components/columngroup/ColumnGroup');