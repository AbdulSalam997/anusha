import * as React from 'react';

declare module 'primereact/columngroup' {
    // tslint:disable-next-line:no-empty-interface
    export interface ColumnGroupProps {
    }

    export class ColumnGroup extends React.Component<ColumnGroupProps, any> { }
}
