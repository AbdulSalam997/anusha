import * as React from 'react';

declare module 'primereact/ripple' {

    export interface RippleProps {
    }

    export class Ripple extends React.Component<RippleProps, any> { }
}
