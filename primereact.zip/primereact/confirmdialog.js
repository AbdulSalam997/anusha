'use strict';

module.exports = require('./components/confirmdialog/ConfirmDialog');
