'use strict';

module.exports = require('./components/datascroller/DataScroller');