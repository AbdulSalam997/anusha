'use strict';

module.exports = require('./components/dialog/Dialog');