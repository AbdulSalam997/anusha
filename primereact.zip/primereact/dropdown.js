'use strict';

module.exports = require('./components/dropdown/Dropdown');