'use strict';

module.exports = require('./components/editor/Editor');