'use strict';

module.exports = require('./components/fieldset/Fieldset');