'use strict';

module.exports = require('./components/fullcalendar/FullCalendar');