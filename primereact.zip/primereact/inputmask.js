'use strict';

module.exports = require('./components/inputmask/InputMask');