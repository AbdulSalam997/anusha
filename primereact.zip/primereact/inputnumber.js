'use strict';

module.exports = require('./components/inputnumber/InputNumber');