'use strict';

module.exports = require('./components/menu/Menu');