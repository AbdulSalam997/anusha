'use strict';

module.exports = require('./components/orderlist/OrderList');