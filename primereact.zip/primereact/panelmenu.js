'use strict';

module.exports = require('./components/panelmenu/PanelMenu');