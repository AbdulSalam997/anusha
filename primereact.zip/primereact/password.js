'use strict';

module.exports = require('./components/password/Password');