'use strict';

module.exports = require('./components/picklist/PickList');