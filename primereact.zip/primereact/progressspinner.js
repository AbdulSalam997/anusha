'use strict';

module.exports = require('./components/progressspinner/ProgressSpinner');