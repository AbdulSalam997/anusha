'use strict';

module.exports = require('./components/rating/Rating');