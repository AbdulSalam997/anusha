'use strict';

module.exports = require('./components/ripple/Ripple');
